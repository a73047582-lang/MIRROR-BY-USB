package com.example.usbmirrorstarter

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var usbManager: UsbManager
    private lateinit var output: TextView

    private val permissionAction = "com.example.usbmirrorstarter.USB_PERMISSION"

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                permissionAction -> {
                    val device = getUsbDevice(intent)
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    if (device != null) {
                        appendLine(if (granted) {
                            "USB permission granted for ${device.deviceName}"
                        } else {
                            "USB permission denied for ${device.deviceName}"
                        })
                    }
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    appendLine("USB device attached.")
                    showConnectedDevices()
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    appendLine("USB device disconnected.")
                    showConnectedDevices()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        output = TextView(this).apply {
            textSize = 16f
            setPadding(24, 20, 24, 20)
            text = "USB Link Checker\n\nThis is a connection-test prototype, not the screen-mirroring app yet.\n"
        }

        val refresh = Button(this).apply {
            text = "Refresh USB devices"
            setOnClickListener { showConnectedDevices() }
        }
        val request = Button(this).apply {
            text = "Request USB permission"
            setOnClickListener { requestPermissionsForDevices() }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(16, 16, 16, 16)
            addView(refresh)
            addView(request)
            addView(output)
        }
        val scroll = ScrollView(this).apply { addView(layout) }
        setContentView(scroll)

        val filter = IntentFilter().apply {
            addAction(permissionAction)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(usbReceiver, filter)
        }

        showConnectedDevices()
    }

    private fun getUsbDevice(intent: Intent): UsbDevice? {
        return if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
        }
    }

    private fun showConnectedDevices() {
        val devices = usbManager.deviceList.values
        val text = StringBuilder()
        text.append("USB host support: ")
            .append(if (packageManager.hasSystemFeature("android.hardware.usb.host")) "available" else "not reported")
            .append("\n\n")
        if (devices.isEmpty()) {
            text.append("No USB devices are visible to this phone right now.\n\n")
            text.append("Connect the phones using the OTG arrangement, unlock both phones, and tap Refresh. ")
            text.append("If the list stays empty, Android may not expose the other phone as a USB device.")
        } else {
            text.append("Detected ${devices.size} device(s):\n\n")
            devices.forEachIndexed { index, device ->
                text.append("${index + 1}. ${device.deviceName}\n")
                text.append("Vendor ID: ${device.vendorId}\n")
                text.append("Product ID: ${device.productId}\n")
                text.append("Class: ${device.deviceClass}; Subclass: ${device.deviceSubclass}\n")
                text.append("USB permission: ${usbManager.hasPermission(device)}\n\n")
            }
        }
        output.text = text.toString()
    }

    private fun requestPermissionsForDevices() {
        val devices = usbManager.deviceList.values
        if (devices.isEmpty()) {
            appendLine("No USB device detected. Try reconnecting the cable and refreshing.")
            return
        }
        devices.forEach { device ->
            if (usbManager.hasPermission(device)) {
                appendLine("Permission already granted for ${device.deviceName}")
            } else {
                val intent = Intent(permissionAction).setPackage(packageName)
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                val pendingIntent = PendingIntent.getBroadcast(this, device.deviceId, intent, flags)
                usbManager.requestPermission(device, pendingIntent)
            }
        }
    }

    private fun appendLine(line: String) {
        output.append("\n\n$line")
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(usbReceiver)
        } catch (_: IllegalArgumentException) {
        }
    }
}
