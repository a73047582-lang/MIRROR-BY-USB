# USB Link Checker — first prototype

This is a small Android project to test whether the Moto G45 (used as the USB host) can see the OPPO K13 Turbo Pro when connected through the proposed OTG cable arrangement.

## Important
This is **not yet a screen-mirroring app** and does not create an APK by itself. It is a first diagnostic step because USB host/peripheral roles must be confirmed before implementing a video transport. Android normally does not let a regular app make a phone expose an arbitrary custom USB peripheral interface, so a visible device here still does not guarantee that screen streaming is possible.

## How to build
Open this folder in Android Studio on a computer, or import it into a compatible Android Gradle build service. Build the `app` module to create an APK. This project has not been compiled or tested on the user's phones.

## How to test
1. Install the APK on the Moto G45.
2. Connect the phones using the OTG arrangement and unlock both.
3. Open USB Link Checker and tap **Refresh USB devices**.
4. If a device appears, tap **Request USB permission** and allow it.
5. Record what the app reports, including vendor/product IDs, or report that no device appears.

## Planned next steps
If a usable USB interface is exposed, investigate whether it can carry encoded video. If no compatible interface is available, we must change the connection design; we should not promise 1080p/60 FPS, 10-bit colour, or background streaming before testing.
